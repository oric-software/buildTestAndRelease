

extern int gDsbLen;

extern ErrorCode t_p1(signed char *ptr_text,signed char *t,int *ll,int *ptr_size_written);
extern ErrorCode t_p2(signed char *t, int *ll, int fl, int *al);
extern int b_term(char *s, int *v, int *l, int pc);

