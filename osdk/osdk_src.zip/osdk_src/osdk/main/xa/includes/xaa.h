

// f=0 -> labels muessen da sein, f=1 -> eSEGMENT_UNDEF entry 
extern ErrorCode evaluate_expression(signed char *s, int *v, int *l, int xpc, int *afl, int *label, int f);

