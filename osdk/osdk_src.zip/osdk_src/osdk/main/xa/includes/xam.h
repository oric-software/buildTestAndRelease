

extern FILE *xfopen(const char *fn,const char *mode);
extern void reg_include(char*);

