



#define TOOL_VERSION_MAJOR	0
#define TOOL_VERSION_MINOR	2

